#!/bin/bash

# remon_syn와 remon_agt를 한곳에 설치
# uid생성하고 syn과 agt 필요파일 생성
# uid생성, syn 관련 주석처리 후 1번과 같은 방법으로 실행 
#  

#환경변수 등록
remon_path=/home/remon
nic_name=enp0s3 #ifconfig로 할당된 NIC이름 검색
uid_count=10 #6개 agent for redis-instance, 3개 host, 1 개 group uid  
db_server_ip=192.168.1.49
db_server_port=3306
redis_port1=6379
company_name=COMPANY
group_name=single
agent_version=2.22
cluster_type=0

uid_pos1=1 #3, 5
host_pos=7 #first server #8, 9
group_pos=10 #group uid position


# mac, ip 환경변수 등록 
IPaddress=$(ip addr show $nic_name | grep "inet\b" | awk '{print $2}' | cut -d/ -f1)
macAddress=$(ip addr show $nic_name | grep "ether\b" | awk '{print $2}' | cut -d/ -f1)


# uid생성 
./1.uid.sh $remon_path $nic_name $uid_count

i=1

while read line; do
    str="$line"
    # echo $str
    echo "${str:(-32)}"
    uid=${str:(-32)}
    echo $i
    if [ $i -eq $group_pos ]
    then
        group_uid=$uid
    elif [ $i -eq $host_pos ]
    then
        host_uid=$uid
    elif [ $i -eq $uid_pos1 ]
    then
        uid_1=$uid
    fi
    i=$(expr $i + 1)
done < uids.txt

#syn conf생성
./3.syn_conf.sh $remon_path $db_server_ip $db_server_port $company_name $nic_name

#agt1 conf (id는 uid, group_uid, host_uid순서)
./4.agt_conf.sh $remon_path $db_server_ip $db_server_port $uid_1 $IPaddress'_'$redis_port1 $IPaddress $redis_port1 $group_uid $group_name $cluster_type $host_uid $nic_name $company_name


#agent db등록
$remon_path/bin/remon_reg -o ins -s all -f $remon_path/conf/$IPaddress'_'$redis_port1.conf
# ./5regist_agt.sh $remon_path $IPaddress $redis_port1
#syncer 실행
$remon_path/bin/remon_syn -s -f $remon_path/conf/$db_server_ip'_'$db_server_port.conf
#agent 실행
$remon_path/bin/remon_agt -s -f $remon_path/conf/$IPaddress'_'$redis_port1.conf
#rsc
$remon_path/bin/remon_rsc -s -f $remon_path/conf/$IPaddress'_'$redis_port1.conf
# agent process 조회
# ps -C remon_agt -o user,pid,pcpu,pmem,size,vsize,cmd
