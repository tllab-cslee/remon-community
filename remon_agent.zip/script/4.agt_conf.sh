#!/bin/bash

#remon_home = ${1}
#db serverip(mi) = ${2}
#db server port(mp) = ${3}
#instance uid(iu) = ${4}
#agent name(in) = ${5}
#redis server ip(ii) = ${6}
#redis server port(ip)=${7}
#group uid(gu) = ${8}
#group name(gn) = ${9}
#group type(gt) = ${10} 
#host uid(ou) = ${11}
#nic = ${12}
#company name(sc) = ${13}


# sample
# ./4generate_agt_conf.sh /home/remon 192.168.1.255 33306 Cc647f2c43d39fcbb3f1e00620b8bbf1c 192.168.1.255_6379 192.168.1.255 6379 c647f2c43d39fcbb3f1e00620b8bbf1c bangsan 1 c647f2c43d39fcbb3f1e00620b8bbf1c enp0s3 CSLEE

# echo "${1}/bin/remon_agtconf -mi ${2} -mp ${3} -md remon -mu remon -mw cslee -iu ${4} -in ${5} -ii ${6} -ip ${7} -gu ${8} -gn ${9} -gt ${10} -ou ${11} -of ${12} -ac ${13} -al ${1}/conf/${6}'_'${7}.lic -ap ${1}/conf/${6}'_'${7}.pid -ag ${1}/log/${6}'_'${7}.log > ${1}/conf/${6}'_'${7}.conf"

${1}/bin/remon_agtconf -mi ${2} -mp ${3} -md remon -mu remon -mw cslee -iu ${4} -in ${5} -ii ${6} -ip ${7} -gu ${8} -gn ${9} -gt ${10} -ou ${11} -of ${12} -ac ${13} -al ${1}/conf/${6}'_'${7}.lic -ap ${1}/conf/${6}'_'${7}.pid -ag ${1}/log/${6}'_'${7}.log > ${1}/conf/${6}'_'${7}.conf
