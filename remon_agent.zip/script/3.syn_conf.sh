#!/bin/bash

#remon_home = ${1}
#db serverip(mi) = ${2}
#db server port(mp) = ${3}
#company name(sc) = ${4}
#nic(sf) = ${5}

# sample
# ./3generate_syn_conf.sh /home/remon 192.168.1.255 3306 COMPANY enp0s3


${1}/bin/remon_synconf -mi ${2} -mp ${3} -md remon -mu remon -mw cslee -sc ${4} -sf ${5} -sl ${1}/conf/${2}'_'${3}.lic -sp ${1}/conf/${2}'_'${3}.pid -sg ${1}/log/${2}'_'${3}.log > ${1}/conf/${2}'_'${3}.conf

