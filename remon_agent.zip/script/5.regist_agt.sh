#!/bin/bash

remon_home=${1}
server_ip=${2}
server_port=${3}

# sample
# ./5regist_agt.sh /home/remon 192.168.1.255 3306

echo "${remon_home}/bin/remon_reg -o ins -s all -f ${remon_home}/conf/${server_ip}'_'${server_port}.conf"
${remon_home}/bin/remon_reg -o ins -s all -f ${remon_home}/conf/${server_ip}'_'${server_port}.conf
