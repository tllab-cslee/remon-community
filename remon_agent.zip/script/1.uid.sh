#!/bin/bash

# generate uid 
# remon_home nic, countOfUid
# sample
# ./1generate_uid.sh /home/remon enp0s3 1
${1}/bin/remon_uid ${2} ${3} > uids.txt


