drop database remon;
drop user remon;
create database remon ;
create user 'remon'@'%' identified by 'cslee';
grant all privileges on remon.* to 'remon'@'%';
flush privileges;

use remon;


CREATE TABLE os_host
(
    host_id               VARCHAR(512) NOT NULL,
    host_nm               VARCHAR(1024) NOT NULL,
    network_iface         VARCHAR(128) NOT NULL,
    os_nm                 VARCHAR(1024) NOT NULL,
    os_ver                VARCHAR(1024) NULL,
    mod_ts                VARCHAR(30) NOT NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE os_host ADD  PRIMARY KEY (host_id) ;

ALTER TABLE os_host ADD cpu_usage double NULL;
ALTER TABLE os_host ADD memory_usage double NULL;
ALTER TABLE os_host ADD disk_usage double NULL;


CREATE TABLE remon_option
(
    opt_id                INTEGER NOT NULL PRIMARY KEY ,
    opt_nm                VARCHAR(100) NOT NULL,
    opt_value             INTEGER NOT NULL,
    description           VARCHAR(100) NULL,
    mod_ts                VARCHAR(30) NOT NULL,
	syncer_ver  VARCHAR(10) NULL default 'v1.0.0',
	is_updated					boolean default false
)row_format=compressed key_block_size=8
;


CREATE TABLE remon_option_log
(
    opt_log_id	BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    opt_id      INT NOT NULL,
    prev_value  INT,
    cur_value   INT,
    user_id     varchar(512),
    mod_ts      varchar(30)
);


alter table remon_option_log
ADD Foreign key (opt_id) REFERENCES remon_option (opt_id);


CREATE TABLE redis_grp
(
	grp_id                VARCHAR(512) NOT NULL,
	grp_nm                VARCHAR(1024) NOT NULL,
	cluster_type          INTEGER NOT NULL,
	preference            TINYINT NULL,
	mod_ts                VARCHAR(30) NOT NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE redis_grp ADD  PRIMARY KEY (grp_id) ;

-- ALTER table remon_option
-- ADD syncer_ver  VARCHAR(10) NULL default 'v1.0.0',


-- ALTER TABLE redis_inst
-- ADD agent_ver   VARCHAR(10) NULL default 'v1.0.0',
-- ADD is_master	boolean null default false;


CREATE TABLE redis_inst
(
	inst_id               VARCHAR(512) NOT NULL,
	inst_nm               VARCHAR(1024) NOT NULL,
	ip_addr               VARCHAR(128) NOT NULL,
	port                  INTEGER NOT NULL,
	inst_type             TINYINT NOT NULL,
	grp_id                VARCHAR(512) NOT NULL,
	host_id               VARCHAR(512) NOT NULL,
	mod_ts                VARCHAR(30) NOT NULL,
    agent_ver             VARCHAR(10) NULL default 'v1.0.0',
	is_master				boolean null default false,
	node_id				  VARCHAR(48) NULL,
	master_node_id		  VARCHAR(48) NULL
)row_format=compressed key_block_size=8
;

-- ALTER TABLE redis_inst add node_id varchar(48) null;
-- ALTER TABLE redis_inst add master_node_id varchar(48) null;


ALTER TABLE redis_inst ADD  PRIMARY KEY (inst_id) ;

CREATE INDEX fk_redis_inst_01 ON redis_inst ( grp_id) ;

CREATE INDEX fk_redis_inst_02 ON redis_inst ( host_id) ;

CREATE TABLE remon_dyn_limit
(
	inst_id               VARCHAR(512) NOT NULL,
	stats_id              VARCHAR(512) NOT NULL,
	month_cycle           INTEGER NOT NULL,
	week_cycle            INTEGER NOT NULL,
	day_cycle             INTEGER NOT NULL,
	hour_cycle            INTEGER NOT NULL,
	dyn_limit_num_val     DOUBLE NULL,
	dyn_limit_delta_slope_num_val  DOUBLE NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE remon_dyn_limit
	ADD  PRIMARY KEY (inst_id,stats_id,month_cycle,week_cycle,day_cycle,hour_cycle)
;

CREATE INDEX fk_remon_limit_01 ON remon_dyn_limit ( inst_id, stats_id) ;

CREATE TABLE remon_err_log
(
	seq_no                BIGINT NOT NULL  AUTO_INCREMENT PRIMARY KEY,
	scn                   BIGINT NOT NULL,
	inst_id               VARCHAR(512) NOT NULL,
	stats_id              VARCHAR(512) NULL,
	err_type              VARCHAR(512)  NULL,
	err_level             INTEGER       NULL,
	err_code              INTEGER       NULL,
	err_msg               VARCHAR(2048) NULL,
	tran_batch_prcs_yn    boolean NULL,
	scn_gen_ts            CHAR(30) NOT NULL,
	tran_batch_prcs_ts    CHAR(30) NULL    ,
        msg_no                BIGINT
)row_format=compressed key_block_size=8
;

CREATE INDEX idx_remon_err_log_01 ON remon_err_log ( scn_gen_ts, scn, inst_id) ;

CREATE INDEX idx_remon_err_log_02 ON remon_err_log ( tran_batch_prcs_ts, scn, inst_id) ;

CREATE INDEX idx_remon_err_log_03 ON remon_err_log ( tran_batch_prcs_yn, scn, inst_id) ;

CREATE INDEX fk_remon_stats_log_hdr_01 ON remon_err_log ( scn, inst_id) ;

CREATE TABLE remon_err_tran
(
	seq_no                BIGINT NOT NULL,
	user_id               VARCHAR(512) NOT NULL,
	tran_media_type       INTEGER NOT NULL,
	cell_phone_no         VARCHAR(32) NULL,
	mail_addr             VARCHAR(128) NULL,
	tran_result_code      INTEGER NULL,
	tran_msg_title        VARCHAR(512) NULL,
	tran_msg_body         TEXT NULL,
	tran_ts               VARCHAR(30) NULL,
        msg_no                BIGINT
)row_format=compressed key_block_size=8 default character set utf8 collate utf8_general_ci
;

ALTER TABLE remon_err_tran ADD  PRIMARY KEY (seq_no,user_id,tran_media_type) ;

ALTER TABLE remon_err_tran Modify column seq_no BIGINT NOT NULL AUTO_INCREMENT;

CREATE INDEX fk_remon_err_log_01 ON remon_err_tran ( seq_no) ; 

CREATE INDEX fk_remon_user_01 ON remon_err_tran ( user_id) ; 

CREATE TABLE remon_limit
(
	inst_id               VARCHAR(512) NOT NULL,
	stats_id              VARCHAR(512) NOT NULL,
	limit_comp            SMALLINT NULL,
	limit_type            SMALLINT NOT NULL,
	static_limit_num_val  DOUBLE NULL,
	static_limit_str_val  VARCHAR(100) NULL,
	static_limit_delta_slope_use  boolean NULL,
	static_limit_delta_slope_num_val  DOUBLE NULL,
	dyn_limit_delta_slope_use  boolean NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE remon_limit ADD  PRIMARY KEY (inst_id,stats_id) ;

CREATE INDEX fk_redis_inst_02 ON remon_limit ( inst_id) ;

CREATE INDEX fk_remon_stats_01 ON remon_limit ( stats_id) ;

CREATE TABLE remon_scn_lck
(
	scn                   BIGINT NOT NULL,
	scn_gen_ts            VARCHAR(30) NOT NULL,
	scn_vote_gap          SMALLINT NOT NULL,
	scn_chg_interval      BIGINT NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE remon_scn_lck ADD  PRIMARY KEY (scn) ;

CREATE TABLE remon_scn_nolck
(
	scn                   BIGINT NOT NULL,
	scn_gen_ts            VARCHAR(30) NOT NULL,
	scn_vote_gap          SMALLINT NOT NULL,
	scn_chg_interval      BIGINT NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE remon_scn_nolck ADD  PRIMARY KEY (scn) ;

CREATE TABLE remon_stats
(
	stats_id              VARCHAR(512) NOT NULL,
	level_count           INTEGER NOT NULL,
	level1                VARCHAR(100) NULL,
	level2                VARCHAR(100) NULL,
	level3                VARCHAR(100) NULL,
	level4                VARCHAR(100) NULL,
	level5                VARCHAR(100) NULL,
	value_type            INTEGER NOT NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE remon_stats ADD  PRIMARY KEY (stats_id) ;

CREATE UNIQUE INDEX idx_remon_stats_01 ON remon_stats ( level1, level2, level3, level4, level5) ;

CREATE TABLE remon_minimum_stats
(
    grp_id  VARCHAR(512) NOT NULL,
    level1 	VARCHAR(100) NOT NULL,
    level2	VARCHAR(100) NOT NULL,
    level3	VARCHAR(100) NULL,
    max_val 	VARCHAR(100) NULL,
    max_delta 	DOUBLE NULL,
    min_val 	VARCHAR(100) NULL,
    min_delta 	DOUBLE NULL
)row_format=compressed key_block_size=8
;

-- ALTER TABLE remon_minimum_stats ADD PRIMARY KEY (level1, level2, level3);
CREATE UNIQUE INDEX idx_remon_minimum_stats ON remon_minimum_stats (grp_id, level1, level2, level3);

-- select *
-- from remon_minimum_stats
-- where level1='os_cpu'
-- and level2='cpu_used_pct'

CREATE TABLE remon_stats_cal
(
	inst_id               VARCHAR(512) NOT NULL,
	stats_id              VARCHAR(512) NOT NULL,
	yyyy                  INTEGER NOT NULL,
	month_cycle           INTEGER NOT NULL,
	week_cycle            INTEGER NOT NULL,
	day_cycle             INTEGER NOT NULL,
	hour_cycle            INTEGER NOT NULL,
	samp_cnt              INTEGER NULL,
	avg_num_val           DOUBLE NULL,
	avg_delta_num_val     DOUBLE NULL,
	avg_delta_slope_num_val  DOUBLE NULL,
	max_num_val           DOUBLE NULL,
	max_delta_num_val     DOUBLE NULL,
	max_delta_slope_num_val  DOUBLE NULL,
	min_num_val           DOUBLE NULL,
	min_delta_num_val     DOUBLE NULL,
	min_delta_slope_num_val  DOUBLE NULL,
	samp_devi_num_val     DOUBLE NULL,
	samp_devi_delta_num_val  DOUBLE NULL,
	samp_devi_delta_slope_num_val  DOUBLE NULL,
	samp_vari_num_val     DOUBLE NULL,
	samp_vari_delta_num_val  DOUBLE NULL,
	samp_vari_delta_slope_num_val  DOUBLE NULL
)row_format=compressed key_block_size=8
;

ALTER TABLE remon_stats_cal
	ADD  PRIMARY KEY (inst_id,stats_id,yyyy,month_cycle,week_cycle,day_cycle,hour_cycle)
;

CREATE INDEX fk_redis_inst_03 ON remon_stats_cal ( inst_id) ; 

CREATE INDEX fk_remon_stats_03 ON remon_stats_cal ( stats_id) ;

CREATE TABLE remon_stats_log_dtl
(
	scn                   BIGINT NOT NULL,
	inst_id               VARCHAR(512) NOT NULL,
	stats_id              VARCHAR(512) NOT NULL,
	str_val               VARCHAR(100) NULL,
	num_val               DOUBLE NULL,
	delta_num_val         DOUBLE NULL,
	delta_slope_num_val   DOUBLE NULL,
	cumul_num_val         DOUBLE NULL
)row_format=compressed key_block_size=8
partition by range(scn)
(
partition p100 values less than(100)
);

ALTER TABLE remon_stats_log_dtl
	ADD  PRIMARY KEY (scn,inst_id,stats_id)
;

CREATE INDEX fk_remon_stats_log_hdr_01 ON remon_stats_log_dtl ( scn, inst_id) ;

CREATE INDEX fk_remon_stats_01 ON remon_stats_log_dtl ( stats_id) ;

CREATE TABLE remon_stats_log_hdr
(
	scn                            BIGINT NOT NULL,
	inst_id                        VARCHAR(512) NOT NULL,
	scn_gen_ts                     VARCHAR(30) NOT NULL,
	log_start_ts                   VARCHAR(30) NOT NULL,
	log_end_ts                     VARCHAR(30) NOT NULL,
	log_os_result_code             INTEGER NOT NULL,
	log_os_result_msg              VARCHAR(2048) NOT NULL,
	log_redis_result_code          INTEGER NOT NULL,
	log_redis_result_msg           VARCHAR(2048) NOT NULL,
	log_clu_result_code            INTEGER NOT NULL,
	log_clu_result_msg             VARCHAR(2048) NOT NULL,
	log_redis_client_result_code   INTEGER NOT NULL,
	log_redis_client_result_msg    VARCHAR(2048) NOT NULL,
	os_vote                        boolean NOT NULL,
	clu_vote                       boolean NOT NULL
)row_format=compressed key_block_size=8
partition by range(scn)
(
partition p100 values less than(100)
);

ALTER TABLE remon_stats_log_hdr ADD  PRIMARY KEY (scn,inst_id) ; 

CREATE INDEX idx_remon_stats_log_hdr_01 ON remon_stats_log_hdr ( scn_gen_ts, inst_id, scn) ;

CREATE INDEX fk_remon_inst_01 ON remon_stats_log_hdr ( inst_id) ;

CREATE TABLE remon_user
(
	user_id               VARCHAR(512) NOT NULL,
	user_nm               VARCHAR(1024) NOT NULL,
	cmpn_nm               VARCHAR(1024) NOT NULL,
	passwd                VARCHAR(1024) NOT NULL,
	mail_addr             VARCHAR(128) NOT NULL,
	cell_phone_no         VARCHAR(32) NOT NULL,
	mail_rcv_yn           boolean NOT NULL,
	sms_rcv_yn            boolean NOT NULL,
	admin_yn              boolean NULL,
	mod_ts                VARCHAR(30) NOT NULL,
        rcv_err_level         tinyint NULL
)row_format=compressed key_block_size=8 default character set utf8 collate utf8_general_ci
;

ALTER TABLE remon_user ADD  PRIMARY KEY (user_id) ;

CREATE TABLE remon_err_msg
(
       msg_no                 BIGINT NOT NULL AUTO_INCREMENT primary key,
       err_level              VARCHAR(100) NULL,
       msg_mail_title         VARCHAR(512) NULL,
       msg_mail_body          TEXT NULL,
       msg_sms                TEXT NULL,
       tran_batch_prcs_code   VARCHAR(100) NULL,
       tran_batch_prcs_ts     TEXT NULL,
       msg_ts                 TEXT NULL
)row_format=compressed key_block_size=8 default character set utf8 collate utf8_general_ci
;

-- ALTER TABLE remon_err_msg ADD  PRIMARY KEY (msg_no) ;

CREATE TABLE remon_client_stats
(
	scn          BIGINT NOT NULL,
	inst_id      VARCHAR(512) NOT NULL,
	client_id    BIGINT NOT NULL,
	addr         VARCHAR(50) NULL,
	fd           BIGINT NULL,
	name         VARCHAR(100) NULL,
	age          BIGINT NULL,
	idle         BIGINT NULL,
        flags        VARCHAR(5) NULL,
        db           BIGINT NULL,
        sub          BIGINT NULL,
        psub         BIGINT NULL,
        multi        BIGINT NULL,
        qbuf         BIGINT NULL,
        qbuf_free    BIGINT NULL,
        obl          BIGINT NULL,
        oll          BIGINT NULL,
        omem         BIGINT NULL,
        events       VARCHAR(5) NULL,
        cmd          VARCHAR(100) NULL,
        mod_ts       VARCHAR(30) NOT NULL
)row_format=compressed key_block_size=8
partition by range(scn)
(
partition p100 values less than(100)
);

ALTER TABLE remon_client_stats ADD  PRIMARY KEY (scn,inst_id,client_id) ;

CREATE INDEX fk_redis_inst_01 ON remon_client_stats ( inst_id) ;

CREATE INDEX idx_remon_client_stats_01 on remon_client_stats (addr);

CREATE INDEX idx_remon_client_stats_02 on remon_client_stats (mod_ts);

ALTER TABLE redis_inst ADD FOREIGN KEY fk_redis_inst_grp_01 (grp_id) REFERENCES redis_grp(grp_id) ;

ALTER TABLE redis_inst ADD FOREIGN KEY fk_os_host_01 (host_id) REFERENCES os_host(host_id) ;


insert into remon_scn_lck
(scn,scn_gen_ts,scn_vote_gap)
values
(1,'0000-00-00 00:00:00.000',0);

insert into remon_scn_nolck
(scn,scn_gen_ts,scn_vote_gap)
values
(1,'0000-00-00 00:00:00.000',0);

INSERT INTO remon_user 
(user_id,user_nm,cmpn_nm,passwd,mail_addr,cell_phone_no,mail_rcv_yn,sms_rcv_yn,admin_yn,mod_ts)
VALUES
('cslee', 'cslee', 'CSLEE', '$2a$11$kXhndtqUtO1wrWeuSKDki.xOJ5v5dXXHei5LW3miuAzpaPhBWI9YS', 'cslee@cslee.co.kr', '010-0000-0000',FALSE,FALSE,TRUE,NOW());
-- cslee / cslee

insert into remon_option(opt_id, opt_nm, opt_value, description, mod_ts, syncer_ver)
values (1, 'scn_interval', 20, 'interval of scn (second)', now(), '2.2.0'),
       (2, 'partition_cnt', 5, 'count of partition (count)', now(), '2.2.0'),
       (3, 'scn_range', 1000, 'range of scn number for partition', now(), '2.2.0'),
       (4, 'scn_vote_gap', 2, 'scn_vote_gap (count)', now(), '2.2.0');